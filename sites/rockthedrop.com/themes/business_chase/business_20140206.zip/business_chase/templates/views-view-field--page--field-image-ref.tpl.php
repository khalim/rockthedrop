<?php
/**
 * @file
 * This template is used to print a single field in a view.
 *
 * It is not actually used in default Views, as this is registered as a theme
 * function which has better performance. For single overrides, the template is
 * perfectly okay.
 *
 * Variables available:
 * - $view: The view object
 * - $field: The field handler object that can process the input
 * - $row: The raw SQL result that can be used
 * - $output: The processed output that will normally be used.
 *
 * When fetching output from the $row, this construct should be used:
 * $data = $row->{$field->field_alias}
 *
 * The above will guarantee that you'll always get the correct data,
 * regardless of any changes in the aliasing that might happen if
 * the view is modified.
 */
?>
<?php
$current_view = views_get_current_view();
$image_style = tour_builder_ui_get_front_end_image_style($current_view);

$node = node_load($row->field_field_image_ref[0]['raw']['target_id']);

//  print '<img usemap="#image_' . $row->nid . '" src = "' . image_style_url('large', $node->field_slide_image['und'][0]['uri']) . '">';
  print '<img usemap="#image_' . $row->nid . '" src = "' . image_style_url($image_style, $node->field_slide_image['und'][0]['uri']) . '">';
  ?>
  <div id="canvas_<?php print $row->nid; ?>" class="imagemap_canvas" >

  &nbsp;</div>
