<?php
/**
 * @file
 * This template is used to print a single field in a view.
 *
 * It is not actually used in default Views, as this is registered as a theme
 * function which has better performance. For single overrides, the template is
 * perfectly okay.
 *
 * Variables available:
 * - $view: The view object
 * - $field: The field handler object that can process the input
 * - $row: The raw SQL result that can be used
 * - $output: The processed output that will normally be used.
 *
 * When fetching output from the $row, this construct should be used:
 * $data = $row->{$field->field_alias}
 *
 * The above will guarantee that you'll always get the correct data,
 * regardless of any changes in the aliasing that might happen if
 * the view is modified.
 */
?>

<?php
$slideshow_id = $view->name . '-' . $view->current_display;  // Some reflection to know what view / display we're working with.
/*
$slideshow_id = $view->name . '-' . $menu_active_item = variable_get($view->name . ':' . $view->current_display . 'menu_active_item');
$view->current_display;  // Some reflection to know what view / display we're working with.
*/
// Initialize a few variables
$js_draw_function = "";
$converted_parameters = "";
$map_areas = array();
global $scale;  // Globalized until converted to a DB variable

// Build an array of image map areas that need to be linked and drawn on the image.
foreach($row->field_field_slide_map_link as $slide_map_link) {
  if (!empty($slide_map_link['rendered']['entity'])) {
    foreach($slide_map_link['rendered']['entity']['field_collection_item'] as $entity_id => $collection) {
      $map_areas[] = $collection;
    }
  }
}

if (!isset($scale) || "array" != gettype($scale)) {
  $scale = array();
}
if (empty($scale)) {
  /*
   * Some more reflection to calculate differences between the image where original
   * map area was selected and the image it will be drawn and built on.
   */
  $current_view = views_get_current_view();
  $tour_image_style = tour_builder_ui_get_front_end_image_style($current_view);
  $admin_image_style = "tour_builder_admin";

  // Grab that node where image was originally loaded
  $node = node_load($row->field_field_image_ref[0]['raw']['target_id']);

  // Get the admin image.  NOT by http (commented) but by local filesystem (not commented)
//list($tour_admin_image['width'], $tour_admin_image['height'], $junk) = getimagesize(image_style_url($admin_image_style, $node->field_slide_image['und'][0]['uri']));
  $image_file = drupal_realpath(image_style_path($admin_image_style, $node->field_slide_image['und'][0]['uri']));
  if (file_exists($image_file)) {
    list($tour_admin_image['width'], $tour_admin_image['height'], $junk) = getimagesize($image_file);
  } else {
    // if the image wasn't found then get it over http: to force the image to be created
    list($tour_admin_image['width'], $tour_admin_image['height'], $junk) = getimagesize(image_style_url($admin_image_style, $node->field_slide_image['und'][0]['uri']));
  }

  // Get the target image  NOT by http (commented) but by local filesystem (not commented)
//list($tour_image['width'], $tour_image['height'], $junk) = getimagesize(image_style_url($tour_image_style, $node->field_slide_image['und'][0]['uri']));
  $image_file = drupal_realpath(image_style_path($tour_image_style, $node->field_slide_image['und'][0]['uri']));
  if (file_exists($image_file)) {
    list($tour_image['width'], $tour_image['height'], $junk) = getimagesize($image_file);
  } else {
    // if the image wasn't found then get it over http: to force the image to be created
    list($tour_image['width'], $tour_image['height'], $junk) = getimagesize(image_style_url($tour_image_style, $node->field_slide_image['und'][0]['uri']));
  }
  
  $scale = product_tour_builder_image_scale($tour_admin_image['width'], $tour_admin_image['height'],
                                            $tour_image['width'], $tour_image['height']);
}
?>

<script type="text/javascript">
<!--
var cnv_<?php print $row->nid ?> = document.getElementById("canvas_<?php print $row->nid ?>");
var jg_<?php print $row->nid ?> = new jsGraphics(cnv_<?php print $row->nid ?>);

jg_<?php print $row->nid ?>.setColor("orange");
jg_<?php print $row->nid ?>.setStroke(2);
//-->
<?php foreach ($map_areas as $idx => $area) :
  if (!empty($area['field_shape']['#object']->field_coordinates['und'][0]['safe_value'])) {
    $the_coordinates = $area['field_shape']['#object']->field_coordinates['und'][0]['safe_value'];
  }
  if (!empty($area['field_shape']['#object']->field_shape['und'][0]['value'])) {
    $the_shape = $area['field_shape']['#object']->field_shape['und'][0]['value'];

    switch ($the_shape) {
      case "RECT":
        $js_draw_function = "drawRect";
        $map_areas[$idx]['converted_parameters'] = product_tour_builder_convert_parameters($the_shape, $the_coordinates, $scale);
        break;
      case "ELLIPSE":
        $js_draw_function = "drawEllipse";
        $map_areas[$idx]['converted_parameters'] = product_tour_builder_convert_parameters($the_shape, $the_coordinates, $scale);
        break;
      case "CIRCLE":
        $js_draw_function = "drawEllipse";
        $map_areas[$idx]['converted_parameters'] = product_tour_builder_convert_parameters($the_shape, $the_coordinates, $scale);
        $map_areas[$idx]['circle_map_coords'] = product_tour_builder_convert_ellipse_to_circle_map($the_coordinates, $scale);
        break;
      case "POLY":
        break;
      default :
        break;
    }
  }
  // This is preparation for the JS Graphics library.  before this will appear, the "paint()" function below must be uncommented.
//  print "jg_" . $row->nid . ".$js_draw_function(" . ($the_shape == 'CIRCLE' ? $map_areas[$idx]['circle_map_coords'] : $map_areas[$idx]['converted_parameters']) . ");";
?>
<?php endforeach ?>
// jg_<?php print $row->nid ?>.paint();
<?php foreach ($map_areas as $idx => $area) : // This is the conversion to HTML shape drawing on the images.
                                              // Added onClicks and cursor styling to make it behave like 
                                              // normal Links.
  $area_shape = '';
  if (!empty($area['field_shape']['#object']->field_shape['und'][0]['value'])) {
    $area_shape = $area['field_shape']['#object']->field_shape['und'][0]['value'];
  }
  $top = '';
  $left = '';
  $pre_width = '';
  $pre_height = '';
  if (!empty($area['field_shape']['#object']->field_coordinates['und'][0]['safe_value'])) {
    $new_coords = product_tour_builder_convert_parameters_for_mapping($area['field_shape']['#object']->field_coordinates['und'][0]['safe_value'], $scale);
    list ($left, $top, $pre_width, $pre_height) = explode(",", $new_coords);
  }
  ?>
  jQuery("#canvas_<?php print $row->nid ?>").append('\
    <div style="cursor:pointer; position:absolute; \n\
                top:<?php print $top; ?>px; \n\
                left:<?php print $left; ?>px; \n\
                background-image:url(\'sites/default/files/important_bg.png\'); \n\
                width:<?php print ($pre_width - $left); ?>px; \n\
                height:<?php print ($pre_height - $top); ?>px; \n\
                border:2px solid orange; \n\
                <?php if ($area_shape == "CIRCLE" || $area_shape == "ELLIPSE") : ?>
                  border-radius:50%;\n\
                <?php endif; ?>" \n\
                onClick="Drupal.viewsSlideshow.action({ \'action\': \'goToSlide\', \'slideshowID\': \'<?php print $slideshow_id; ?>\', \'slideNum\': getSlidePosition(<?php print $area['field_link_url']['#items'][0]['target_id']; ?>) });"\n\
         title="<?php print empty($area['field_shape']['#object']->field_title['und'][0]['safe_value']) ? "" : 
                                  $area['field_shape']['#object']->field_title['und'][0]['safe_value']; ?>">\n\
      &nbsp;\n\
    </div>'
  );
<?php endforeach ?>
</script>

<?php /*
 * Removing image map area info from page to simplify HTML decision was made to use clickable divs
 * instead of map areasfor hilighting sake.
<map name="image_<?php echo $row->nid; ?>">
<?php foreach ($map_areas as $idx => $area) : ?>
  <area shape="<?php print $area['field_shape']['#object']->field_shape['und'][0]['value']; ?>" 
  <?php if ($area['field_shape']['#object']->field_shape['und'][0]['value'] == "CIRCLE") : ?>
    coords="<?php print $map_areas[$idx]['converted_parameters'] ?>"
  <?php else : ?>
    coords="<?php print product_tour_builder_convert_parameters_for_mapping($area['field_shape']['#object']->field_coordinates['und'][0]['safe_value'], $scale); ?>"
  <?php endif; ?>
    href="javascript:function() { return false; }"
    onClick="Drupal.viewsSlideshow.action({ 'action': 'goToSlide', 'slideshowID': '<?php print $slideshow_id; ?>', 'slideNum': getSlidePosition(<?php print $area['field_link_url']['#items'][0]['target_id']; ?>) });" 
    <?php if (!empty($area['field_shape']['#object']->field_alt_text['und'][0]['safe_value'])) : ?>
      alt="<?php print $area['field_shape']['#object']->field_alt_text['und'][0]['safe_value']; ?>" 
    <?php endif; ?>
    <?php if (!empty($area['field_shape']['#object']->field_title['und'][0]['safe_value'])) : ?>
      title="<?php print $area['field_shape']['#object']->field_title['und'][0]['safe_value']; ?>"
    <?php endif; ?>
	/>
<?php endforeach; ?>
</map>
 */

