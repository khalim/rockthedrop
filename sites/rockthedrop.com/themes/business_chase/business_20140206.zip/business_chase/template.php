<?php
function business_chase_preprocess_html(&$vars) {
  $meta_viewport = array(
    '#type' => 'html_tag',
    '#tag' => 'meta',
    '#attributes' => array(
      'name' => 'viewport',
      'content' => 'user-scalable=1.0,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0',
    ),
  );

  $meta_apple_mobile = array(
    '#type' => 'html_tag',
    '#tag' => 'meta',
    '#attributes' => array(
      'name' => 'apple-mobile-web-app-capable',
      'content' => 'yes',
    ),
  );

  $meta_format = array(
    '#type' => 'html_tag',
    '#tag' => 'meta',
    '#attributes' => array(
      'name' => 'format-detection',
      'content' => 'telephone=no',
    ),
  );
  
  drupal_add_html_head($meta_viewport, 'meta_viewport');
  drupal_add_html_head($meta_apple_mobile, 'meta_apple_mobile');
  drupal_add_html_head($meta_format, 'meta_format');
  

  $total = 2;

  pager_default_initialize($total, 1, $element = 0);
  $output = theme('pager', array('quantity' => $total));

}

function business_chase_preprocess_pager(&$variables) {
//  print_r($variables);
  $variables['tags'] = array('a','b','c','d','e');
}
/*
function business_chase_pager_first($variables) {
print_r($variables);  
}

function business_chase_pager_last($variables) {
  $variables['JUMP'];
print_r($variables);  
}

function business_chase_pager_previous($variables) {
print_r($variables);  
}

function business_chase_pager_next($variables) {
print_r($variables);  
}
*/
