
function getSlidePosition(slideId) {
  var slideshow = jQuery(".views_slideshow_cycle_slide");
  slide = jQuery("#slide_" + slideId).parent().parent();
  
  return slideshow.index(slide);
}

jQuery(document).ready(function() {
// Move previous and next links to where they need to be flanking pager.
  jQuery('.views-slideshow-pager-fields').prepend(jQuery(".views-slideshow-controls-text-previous"));
  jQuery('.views-slideshow-pager-fields').append(jQuery(".views-slideshow-controls-text-next"));
  
  var flyoutInView = false;
  jQuery(".views-field-field-flyout .tab-wrapper").each(function(){
    jQuery(this).toggle(
      function(){ 
        jQuery(this).parent().parent().animate({left:'48%'});
        flyoutInView = false;
      },  // Second parameter for 'toggle()' below.
      function(){
        jQuery(this).parent().parent().animate({left:'100%'});
        flyoutInView = true;
      }
    );
  });
/*
  jQuery(".views-field-field-flyout .tab-wrapper").each(function(idx){
    if (flyoutInView) {
      jQuery(this)
    }
  }
*/
/*
  jQuery(".views-field-field-flyout .tab-wrapper").toggle(
    function(){ 
      jQuery(".views-field-field-flyout").animate({left:'48%'});
      flyoutInView = false;
    },  // Second parameter for 'toggle()' below.
    function(){
      jQuery(".views-field-field-flyout").animate({left:'100%'});
      flyoutInView = true;
    }
  );
  jQuery("*").click(function(){
    jQuery(".views-field-field-flyout").animate({left:'100%'});
    flyoutInView = false;
  });
*/
});