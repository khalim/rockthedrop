<?php
/*
 * This is a "working" method of modifying a pager
function seven_chase_preprocess_html(&$vars) {
  $total = 20;

  pager_default_initialize($total, 1, $element = 0);
  $output = theme('pager', array('quantity' => $total));

}

function seven_chase_preprocess_pager(&$variables) {
//  print "PAGER";
//  print_r($variables);
  $variables['tags'] = array('a2','b2','- is this ignored? -', 'e2', 'f2' );

}

function seven_chase_preprocess_pager_first(&$variables) {
  $variables['text'] = 'n---';
}

function seven_chase_preprocess_pager_last(&$variables) {
  $variables['text'] = 'n+++';
}

function seven_chase_preprocess_pager_previous(&$variables) {
  $variables['text'] = 'before';
}

function seven_chase_preprocess_pager_next(&$variables) {
  $variables['text'] = 'after';
}
*/