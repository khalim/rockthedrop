ELMS: HTML Export - Export drupal paths to HTML
Copyright (C) 2008-2012  The Pennsylvania State University

Bryan Ollendyke
bto108@psu.edu

Keith D. Bailey
kdb163@psu.edu

12 Borland
University Park, PA 16802

the 2.x branch is a total rewrite of the HTML Export module.  It now provides developer support for custom path selection and page rewrites of paths / data.

It also now supports non-node paths and will render any drupal path.